<?php

declare(strict_types=1);

namespace kaidoMC\ItemFactory\libs\NhanAZ\libBedrock;

class libBedrock {
}
